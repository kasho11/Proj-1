%This function formats a nx2 matrix for plotting
function retval = format_coordinate(a,list)
	retval = list(:,a);
endfunction;